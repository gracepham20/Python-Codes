from room import Room
from maze import Maze


my_rooms = []
my_rooms.append(Room("This room is the entrance."))
my_rooms.append(Room("This room has a table. Maybe a dinning room?"))
my_rooms.append(Room("This room has a piano. Maybe a piano practice room?"))
my_rooms.append(Room("This room has a NBA live stream screen"))
my_rooms.append(Room("This room has an out-door kid play ground!"))
my_rooms.append(Room("This room has a swimming pool"))
my_rooms.append(Room("This room has nothing!"))
my_rooms.append(Room("Please leave this room"))
my_rooms.append(Room("This room has a sofa. Maybe a living room?"))
my_rooms.append(Room("This room is the exit. Good Job."))


#Room 2 is east of room 1

my_rooms[0].setEast(my_rooms[1])
my_rooms[1].setWest(my_rooms[0])

my_rooms[1].setEast(my_rooms[2])
my_rooms[2].setWest(my_rooms[1])

my_rooms[2].setEast(my_rooms[3])
my_rooms[3].setWest(my_rooms[2])

my_rooms[3].setEast(my_rooms[4])
my_rooms[4].setWest(my_rooms[3])

my_rooms[4].setEast(my_rooms[5])
my_rooms[5].setWest(my_rooms[4])

my_rooms[1].setSouth(my_rooms[6])
my_rooms[6].setNorth(my_rooms[1])

my_rooms[3].setNorth(my_rooms[7])
my_rooms[7].setSouth(my_rooms[3])

my_rooms[5].setSouth(my_rooms[8])
my_rooms[8].setNorth(my_rooms[5])

my_rooms[5].setNorth(my_rooms[9])
my_rooms[9].setSouth(my_rooms[5])

my_maze = Maze(my_rooms[0],my_rooms[9])

exit = my_maze.atExit()

print('You lost!', end='')
print('Find the way out!')

while not exit:
    print(my_maze.getCurrent())
    direction = input('Enter direction to move north west east south restart\n')
    
    if direction == 'north':
        if my_maze.getCurrent().getNorth() == None:
            print('Direction invalid, try again.')

        else :
            my_maze.moveNorth()
            print('You go', direction)
        
    elif direction == 'south':
        if my_maze.getCurrent().getSouth() == None:
            print('Direction invalid, try again.')
        else :
            my_maze.moveSouth()
            print('You go', direction)

    elif direction == 'east':
        if my_maze.getCurrent().getEast() == None:
            print('Direction invalid, try again.')
        else:
            my_maze.moveEast()
            print('You go', direction)
    elif direction == 'west':
        if my_maze.getCurrent().getWest() == None:
            print('Direction invalid, try again.')
        else:
            my_maze.moveWest()
            print('You go', direction)
    else:
        print('Direction invalid, try again.')

    if my_maze.atExit():
        exit = True
    
    print('')

print('You found the exit!')