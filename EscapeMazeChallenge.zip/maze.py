class Maze:

    def __init__(self, st=None, ex=None):
	    self.__start_room = st
	    self.__exit_room = ex
	    self.__current = st
	
    def getCurrent(self):
        return (self.__current)
		
    def moveNorth(self):
        if self.__current.getNorth() == None:
            return False
        else:
            self.__current = self.__current.getNorth()
		
    def moveSouth(self):
        if self.__current.getSouth() == None:
            return False
        else:
            self.__current = self.__current.getSouth()
		
    def moveEast(self):
        if self.__current.getEast() == None:
            return False
        else:
            self.__current = self.__current.getEast()
		
    def moveWest(self):
        if self.__current.getWest() == None:
            return False
        else:
            self.__current = self.__current.getWest()
		
    def atExit(self):
        if self.__current == self.__exit_room:
            return True
        else:
            return False
		
    def reset(self):
        self.__current = self.__start_room