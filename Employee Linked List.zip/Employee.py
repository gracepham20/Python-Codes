# Student name: Grace Pham

class Employee:
    def __init__(self, empID = None,payRate =0.0, workHour=0.0, wages= 0.0):
        self.empID = empID
        self.workHour = workHour
        self. payRate = payRate
        self.wages =  wages

    def get_empID(self):
        return self.empID
    def set_empID(self, empID):
        self.empID = empID
    
    def get_workHour(self):
        return self.workHour
    def set_workHour(self, updatedHour):
        self.workHour = updatedHour
        self.wages = self.workHour * self.payRate

    def get_payRate(self):
        return self.payRate
    def set_payRate(self, updatedRate):
        self.payRate = updatedRate
        self.wages = self.workHour * self.payRate

    def get_wages(self):
        return self.wages
    def set_wages(self,wages):
        self.wages= wages
    
    def __str__(self):
        return 'Employee ID: '+ str(self.empID)+'\nNumber of work hours: '+str(self.workHour)+'\nHourly Pay Rate: '+ str(self.payRate)+'\nGross Wages: '+str(self.wages)

