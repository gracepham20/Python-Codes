# Student name: Grace Pham
# Student ID: 14291331
# Reference: This is the class Node script from the lecture notes.

class Node():
    def __init__(self, data = None, next = None):
        self.__data = data
        self.__next = next
    
    def getData(self):
        return self.__data
    
    def getNext(self):
        return self.__next
    
    def setData(self,d):
        self.__data = d

    def setNext(self,n):
        self.__next = n
