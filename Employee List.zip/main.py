# Student name: Grace Pham
# Student ID: 14291331
# This is the main script to run the program

from LinkedList import *
from Node import *
from Employee import *

def run_program():

    employees = LinkedList()
    listID = []

    while True:
        
        print('\n*** CS 172 Payroll Simulator ***')
        print('a. Add New Employee')
        print('b. Enter Hours Worked')
        print('c. Display Payroll')
        print('d. Update Employee Hourly Rate')
        print('e. Remove Employee from Payroll')
        print('f. Exit the program')

        x = input('\nEnter your choice: ')


        if x in ['a','b','c','d','e']:
            if x == 'a':

                validID1 = True
                validHour = True

                while validID1:
                    empID = input('Enter the new employee ID: ')
                    if empID.isdigit() == False:
                        print('Employee ID should be in digits! Try again!')
                        validID1 = True
                    else:
                        validID1 = False
                        listID.append(empID)
                        for o in range(len(listID)-1):
                            if empID == listID[o]:
                                validID1 = True
                                print('This ID has already existed! Try another ID!')
                                         
                while validHour:
                    payRate = input('Enter the hourly rate: ')
                    try:
                        payRate =  float(payRate)
                        if payRate <0:
                            print('Hourly Rate cannot be negative!')
                            validHour = True
                        validHour = False
                    except ValueError:
                        print('Invalid Hourly Rate! Try again!')
                        validHour = True


                    employee = Employee(empID,payRate)
                    employees.append(employee)           


            elif x == 'b':
                for i in range(0, employees.__len__()):
                    p = employees.__getitem__(i).get_empID()
                    workHour = float(input('Enter hours worked for employee '+ str(p)+' : '))
                    employees.__getitem__(i).set_workHour(workHour)
        
                    
            elif x == 'c':
                for i in range(0, employees.__len__()):
                    ID = employees.__getitem__(i).get_empID()
                    pr = employees.__getitem__(i).get_payRate()
                    hw = employees.__getitem__(i).get_workHour()
                    gw = employees.__getitem__(i).get_wages()

                    print('*** Payroll ***')
                    print('Employee ID: ', ID)
                    print('Hourly Rate: ', pr)
                    print('Hours Worked: ', hw)
                    print('Gross Wages: ', gw)

                
            elif x == 'd':
                getid = input('Enter the ID of the employee to update Hourly Rate: ')
                
                for i in range(0, employees.__len__()):
                    if getid == employees.__getitem__(i).get_empID():
                        newpay = float(input('Enter new Hourly Rate: '))
                        employees.__getitem__(i).set_payRate(newpay)

            elif x == 'e':
                getid0 = input('Enter the ID of the employee to remove from payroll: ')
                for i0 in range(0, employees.__len__()):
                    if getid0 == employees.__getitem__(i0).get_empID():
                        employees.remove(getid0)
                        print('Done')
                        break
        elif x =='f':
            print ('Good-Bye!')
            exit()
        else:
            print('Error: Please enter letter a, b, c, d, e, or f. Try again!\n')
        

run_program()