# Student name: Grace Pham
# This file contains the Question class required for the program

class Question:
    def __init__(self, question, option1, option2, option3, option4, answer):
        self.__question= question
        self.__option1= option1
        self.__option2= option2
        self.__option3= option3
        self.__option4= option4
        self.__answer= answer
    def get_ans(self):
        return self.__answer
    def set_Answer (self, a):
        self.__answer = a
    def __str__(self):
        return (self.__question + '\n' +'1. ' + self.__option1 +'\n' + '2. ' + self.__option2 + '\n' + '3. ' + self.__option3 +'\n' + '4. ' + self.__option4)