# Student name: Grace Pham
# This is the main script to run the program

from question import Question

q1= Question('In what place was Christmas once illegal?', 'Russia','Brazil','England','France',3)
q2= Question('In California, it is illegal to eat oranges while doing what?','Working on a computer','Gardening','Bathing','Driving',3)
q3= Question('Coulrophobia means fear of what?','Clowns','Old People','Sacred Things','Jews',1)
q4= Question('How many dimples are there on a regular golf ball?','336','294','418','377',1)
q5= Question('Which of the following is the longest running American animated TV show?', 'TV Funhouse','Rugrats','Simpsons','Pokemon',3)
q6= Question('Every year, over 8,800 people injure themselves with what apparently harmless, tiny object?','Toothpick','Baseball bat','Knife','Pencil',1)
q7= Question('How many pounds of pressure do you need to rip off your ear?','17','11','2','7',4)
q8= Question('At what temperature are Fahrenheit and Celsius the same?', '0','92','50','-40',4)
q9= Question('What are the odds of being killed by space debris?', '1 in 5 billion','1 in 10 billion', '1 in 5 million','1 in 1 trillion',1)
q10= Question('When glass breaks, the cracks move up to how many mph?', '3000','2500', '5000','1000',1)

listq=[q1,q2,q3,q4,q5,q6,q7,q8,q9,q10]

print('Welcome to the Python intro programming quiz')
print('--------------------------------------------')
e=0
player1=0
player2=0
while e <=9:
    while e%2==0:
        print('\nPlayer 1 here is your question:')
        print(listq[e],'\n')
        ans=input('Enter your answer: ')
        if ans in ['1','2','3','4']:
            if int(ans) == listq[e].get_ans():
                print('Excellent! You score!')
                player1 += 1
            else:
                print('That is incorrect. Better luck with the next question.')
            e = e+1
        else:
            print('Error: Your answer must be a value between 1 and 4. Try again.')
    else:
        print('\nPlayer 2 here is your question:')
        print(listq[e],'\n')
        ans=input('Enter your answer: ')
        if ans in ['1','2','3','4']:
            if int(ans) == listq[e].get_ans():
                print('Excellent! You score!')
                player2 += 1
            else:
                print('That is incorrect. Better luck with the next question.')
            e=e+1
        else:
            print('Error: Your answer must be a value between 1 and 4. Try again.')
        

print('\nAnd the final scores are:')
print('Player 1:', player1)
print('Player 2:', player2)
if player1<player2:
    print('Player 2 wins!')
elif player1>player2:
    print('Player 1 wins!')
elif player1==player2:
    print('There is a tie')