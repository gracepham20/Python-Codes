# Student name: Grace Pham
# Student ID: 14291331
# This file contains classes required for the program

class Media:
    def __init__(self, name, mtype, rating):
        self.name = name
        self.mtype = mtype
        self.rating = rating
    def getName(self):
        return self.name
    def getType(self):
        return self.mtype
    def getRating(self):
        return self.rating
    def setName(self, name):
        self.name= name
    def setType(self, mtype):
        self.mtype= mtype
    def setRating(self, rating):
        self.rating= rating
    def __str__(self):
        return "Name: "+str(self.name)+', Type:'+str(self.mtype)+', Rating:'+ str(self.rating)

class Movie(Media):
    def __init__(self, name, mtype, rating, director, rt):
        super().__init__(name, mtype, rating)
        self.director = director
        self.rt = rt
        
    def getDirector(self):
        return self.director
    def getRT(self):
        return self.rt
    def setDirector(self, director):
        self.director = director
    def setRT(self, rt):
        self.rt = rt
    def __str__(self):
        return "Name: "+str(self.name)+', Type: '+str(self.mtype)+', Rating: '+str(self.rating) + ', Director: ' +str(self.director) + ', Running time: ' +str(self.rt)
        
    def play(self):
        print (str(self.name) + ", playing now\n")
    
class Song(Media):
    def __init__(self, name, mtype,  rating, artist, album):
        super().__init__(name, mtype, rating)
        self.artist = artist
        self.album = album
        
    def getArtist(self):
        return self.artist
    def getAlbum(self):
        return self.album
    def setArtist(self, artist):
        self.artist = artist
    def setAlbum(self, album):
        self.album = album
        
    def play(self):
        print (str(self.name)+ ' by ' + str(self.artist) + ", playing now\n")
        
    def __str__(self):
        return "Name: "+str(self.name)+', Type: '+str(self.mtype)+', Rating: '+str(self.rating) + ', Artist: ' +str(self.artist) + ', Album: ' +str(self.album)

class Picture(Media):
    def __init__(self, name, mtype, rating, resolution):
        super().__init__(name, mtype, rating)
        self.resolution = resolution
    
    def getResolution(self):
        return self.resolution
    def setResolution(self, resolution):
        self.resolution = resolution

    def show(self):
        print ("Showing " + str(self.name) +'\n')
        
    def __str__(self):
        return "Name: "+str(self.name)+', Type: '+str(self.mtype)+', Rating: '+str(self.rating) + ', Resolution: ' +str(self.resolution) + ' dpi'