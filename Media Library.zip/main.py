# Student name: Grace Pham
# This is the main script to run the program

def run_program():   
    from media import Media, Movie, Song, Picture


    m1 = Movie ('Shutter','Horror', 7,'Banjong Pisanthanakun' ,'120 min')
    m2 = Movie ('Us', 'Horror', 7, 'Jordan Peele','116 min')
    m3 = Movie ('Avengers','Action', 9, 'Anthony Russo','181 min')
    m4 = Movie ('Spider Man', 'Animation', 8, ' Bob Persichetti','117 min')

    s1 = Song ('You belong with me', 'Country', 7, 'Taylor Swift', 'Fearless')
    s2 = Song ('Happier','Pop', 8, 'Marshmello & Bastille','Happy')
    s3 = Song ('1 Phut', 'Ballad', 9 ,'Andiez','A Minute')
    s4 = Song ('Kill this love', 'Electropop' , 7 , 'BlackPink', 'Square Up')

    p1 = Picture('The Starry Night.png','photo', 9, 400)
    p2 = Picture('Windblow Jackie.jpeg', 'photo', 6 , 600)
    p3 = Picture('D-Day', 'photo.png', 6 , 250)
    p4 = Picture('Michael Jordan.png', 'photo', 8 , 360)

    medialist = [m1,m2,m3,m4,s1,s2,s3,s4,p1,p2,p3,p4]

    while True:

        print ('Welcome to the media library!')
        print ('Enter 1 to display all the items in Media library')
        print ('Enter 2 to display all items in Song library')
        print ('Enter 3 to display all items in Movie library')
        print ('Enter 4 to display all items in Picture library')
        print ('Enter 5 to play a song in Song library')
        print ('Enter 6 to play a movie in Movie library')
        print ('Enter 7 to display a picture in Picture library')
        print ('Enter 8 to quit the program')
        x = input()

        if x in ['1','2','3','4','5','6','7']:
            i1=0
            i2=5
            i3=9
            if x == '1':
                for i1 in range(len(medialist)):
                    print (medialist[i1], '\n')
            elif x == '2':
                for i2 in range(4,8):
                    print(medialist[i2], '\n')
            elif x == '3':
                for i1 in range(4):
                    print(medialist[i1], '\n')
            elif x == '4':
                for i3 in range(8,12):
                    print(medialist[i3], '\n')
            elif x == '5':
                songplay = input('Enter a song\'s name to play:')

                for i2 in range(4,8):
                    if songplay == medialist[i2].getName():
                        medialist[i2].play()
                        break
                    elif songplay != medialist[i2].getName():
                        if i2 < 7:
                            i2+=1
                        elif i2 == 7:
                            print('That song is not in the media library!\n')
            elif x == '6':
                movieplay = input('Enter a movie\'s name to play:')

                for i1 in range(4):
                    if movieplay == medialist[i1].getName():
                        medialist[i1].play()
                        break
                        
                    elif movieplay != medialist[i1].getName():
                        if i1 < 3:
                            i1+=1
                        elif i1 == 3:
                            print('That movie is not in the media library!\n')
            elif x == '7':
                picshow = input('Enter a picture\'s name to display:')

                for i3 in range(8,12):
                    if picshow == medialist[i3].getName():
                        medialist[i3].show()
                        break
                        
                    elif picshow != medialist[i3].getName():
                        if i3 < 11:
                            i3+=1
                        elif i3 == 11:
                            print('That picture is not in the media library!\n')

        elif x =='8':
            print ('Goodbye!')
            exit ()
                
        else:
            print('Error: Please enter a number from 1 to 8. Try again!\n')

if __name__ == "__main__":
    run_program()
